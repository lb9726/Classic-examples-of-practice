

int main(int argc,char* argv[])
{
    //修改用户信息
    //User user("lvlv","00001111",0,"13995648666","1586666@qq.com");
    //if(updateUser("./user.xml",&user))
      //  cout<<"update successfully"<<endl;
    //else
      //  cout<<"update failed"<<endl;
    return 0;
}
