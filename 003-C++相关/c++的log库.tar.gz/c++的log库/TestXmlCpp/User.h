//用户类
#ifndef WIDGET_H
#define WIDGET_H
#include<iostream>
using namespace std;
#include "tinyxml2.h"
using namespace tinyxml2;

class User
{
public:
    User();
    User(const string& userName, const string& password, int gender, const string& mobile, const string& email);
    int insertXMLNode(const char* xmlPath,const User& user);
    XMLElement* queryUserNodeByName(XMLElement* root,const string& userName);
    User* queryUserByName(const char* xmlPath,const string& userName);
    bool updateUser(const char* xmlPath,User* user);
    bool deleteUserByName(const char* xmlPath,const string& userName);
    bool getXMLDeclaration(const char* xmlPath,string& strDecl);
    
private:
    string userName;
    string password;
    int gender;
    string mobile;
    string email;
};
#endif
