!���������Ķ�����, ����[����](https://github.com/slivermeteor/EasyLog/blob/master/readme-zh.md)
# Introduction

EasyLog is a C++ cross-platform lib library to Logging. ( Now only support windows)   

# Project

EasyLog project is the implement of the log system.  
LogTest project is the example of how to use EasyLog.  

# Features

1. At that time (2018.3.26), EasyLog only support Windows. I will add the Linux and Mac's support soon. May the Linux first.

# Update Note

2018.3.27 Update Example. Common/Format.hpp provide the template function to format other types to wstring, like the `sprintf` function in `C`.

