
# used for sanity checking the test harness
# "fail" with an implicit raise

class foo: pass
f = foo()
i = f.a
