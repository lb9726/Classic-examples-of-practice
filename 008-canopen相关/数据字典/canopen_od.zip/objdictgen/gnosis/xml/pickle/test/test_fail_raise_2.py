# used for sanity checking the test harness
# fail a test with an explicit raise, newstyle

raise Exception("AAA")
