__doc__ = """Utilities for manipulating text and XML documents"""

