# used for sanity checking the test harness
# "fail" a test with an explicity raise, oldstyle

raise "AAA"
