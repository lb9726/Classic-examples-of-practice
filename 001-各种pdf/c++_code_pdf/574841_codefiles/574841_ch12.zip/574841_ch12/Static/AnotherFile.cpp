// AnotherFile.cpp

#include <iostream>
using namespace std;

static void f();

void f()
{
  cout << "f\n";
}
