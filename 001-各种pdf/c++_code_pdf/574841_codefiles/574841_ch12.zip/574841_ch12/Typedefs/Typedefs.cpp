#include "SpreadsheetCell.h"
#include "Grid.h"

typedef Grid<SpreadsheetCell> Spreadsheet;

int main(int argc, char** argv)
{
  Spreadsheet mySpreadsheet;
  // Rest of the program.
}

void processSpreadsheet(const Spreadsheet& spreadsheet)
{
  // body omitted
}
