// FirstFile.cpp

void f();

int main(int argc, char** argv)
{
  f();
  return (0);
}
