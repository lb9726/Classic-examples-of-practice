class Demo
{
public:
  static void method() {}
};

int main(int argc, char ** argv)
{
  Demo::method();

  return (0);
}
