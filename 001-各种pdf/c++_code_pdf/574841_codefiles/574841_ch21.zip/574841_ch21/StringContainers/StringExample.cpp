#include <string>
#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
  string str1;

  str1.insert(str1.end(), 'h');
  str1.insert(str1.end(), 'e');
  str1.insert(str1.end(), 'l');
  str1.insert(str1.end(), 'l');
  str1.insert(str1.end(), 'o');

  for (string::const_iterator it = str1.begin(); it != str1.end(); ++it) {
    cout << *it;
  }
  cout << endl;

  return (0);
}
