#include <vector>
using namespace std;

int main(int argc, char** argv)
{
  vector<int> intVector; // creates a vector of ints with zero elements
  return (0);
}
