#include <vector>
using namespace std;

class Element
{
public:
  Element() {}
  ~Element() {}
};

int main(int argc, char** argv)
{
  vector<Element> elementVector;
  return (0);
}
