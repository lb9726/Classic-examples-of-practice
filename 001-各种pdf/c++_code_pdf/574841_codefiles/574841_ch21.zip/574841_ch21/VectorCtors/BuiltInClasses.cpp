#include <vector>
#include <string>
using namespace std;

int main(int argc, char** argv)
{
  vector<string> stringVector(10, "hello");
  return (0);
}
