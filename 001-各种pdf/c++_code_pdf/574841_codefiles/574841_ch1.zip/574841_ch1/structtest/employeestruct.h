// employeestruct.h

typedef struct {
  char    firstInitial;
  char    middleInitial;
  char    lastInitial;
  int     employeeNumber;
  int     salary;
} EmployeeT; 
