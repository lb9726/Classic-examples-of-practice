#include "SpreadsheetCell.h"

int main(int argc, char** argv)
{
  SpreadsheetCell myCell;
  myCell.setValue(6);

  return (0);
}
