// SpreadsheetCell.h
class SpreadsheetCell
{
 public:
  void setValue(double inValue);
  double getValue();

 protected:
  double mValue;
};
