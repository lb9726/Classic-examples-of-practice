// SpreadsheetCell.h
class SpreadsheetCell
{
  void setValue(double inValue);
 public:
  double getValue();

 protected:
  double mValue;
};
