#include <iostream>

using namespace std;

int main(int argc, char** argv)
{
  wcout << L"I am internationally aware."  << endl;
} 
