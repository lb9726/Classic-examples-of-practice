#include "Grid.h"

#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
  Grid<int> myGrid;
  Grid<int, 10> anotherGrid;
  Grid<int, 10, 10> aThirdGrid;

  return (0);
}
