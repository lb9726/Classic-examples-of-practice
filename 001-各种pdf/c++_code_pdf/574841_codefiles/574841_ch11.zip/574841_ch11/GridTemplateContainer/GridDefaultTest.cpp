#include "GridDefault.h"

#include <vector>
#include <deque>
#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
  Grid<int, vector<int> > myIntGrid;
  Grid<int> myIntGrid2;

  return (0);
}
