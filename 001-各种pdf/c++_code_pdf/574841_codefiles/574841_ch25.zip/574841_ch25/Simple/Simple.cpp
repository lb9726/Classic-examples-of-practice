/**
 * Simple.cpp
 *
 * Implementation of a simple class
 *
 */

#include "Simple.h"

int Simple::sStaticInt = 0;   // Initialize static data member

Simple::Simple()
{
  // Implementation of constructor
}

Simple::~Simple()
{
  // Implementation of destructor
}

void Simple::publicMethod()
{
  // Implementation of public method
}

int main(int argc, char** argv)
{
  Simple mySimple;
}
