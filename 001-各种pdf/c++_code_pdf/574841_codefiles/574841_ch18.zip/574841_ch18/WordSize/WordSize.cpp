#include <iostream>

using namespace std;

int main(int argc, char** argv)
{
  int *ptr;

  cout << "ptr size is " << sizeof(ptr) << " bytes" << endl;
}
