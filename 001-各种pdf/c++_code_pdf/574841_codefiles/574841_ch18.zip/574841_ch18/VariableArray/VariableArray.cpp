int main(int argc, char** argv)
{
  int i = 4; 
  char myStackArray[i];  // Not a standard language feature!
}
