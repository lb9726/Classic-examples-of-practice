socket
======

a simple socket library for win and linux, with simple demo

for windows, use vc/socket.dsw

for MinGW, use mingw/Makefile.mingw

for linux, use linux/Makefile
