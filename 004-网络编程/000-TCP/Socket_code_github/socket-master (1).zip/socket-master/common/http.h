//
//  http.h
//  socket
//
//  Created by shenyixin on 14-3-24.
//  Copyright (c) 2014年 shenyixin. All rights reserved.
//

#ifndef socket_http_h
#define socket_http_h

#include "common.h"
void build_http_request(const char *host, char *http_request, int n);

#endif
