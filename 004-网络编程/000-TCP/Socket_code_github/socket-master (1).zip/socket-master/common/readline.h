//
//  readline.h
//  socket
//
//  Created by shenyixin on 14-4-3.
//  Copyright (c) 2014年 shenyixin. All rights reserved.
//

#ifndef socket_readline_h
#define socket_readline_h

ssize_t
Readline(int fd, void *ptr, size_t maxlen);

#endif
