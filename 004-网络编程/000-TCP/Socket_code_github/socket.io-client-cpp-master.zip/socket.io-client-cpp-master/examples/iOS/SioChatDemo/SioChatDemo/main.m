//
//  main.m
//  SioChatDemo
//
//  Created by Melo Yao on 3/30/15.
//  Copyright (c) 2015 Melo Yao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
