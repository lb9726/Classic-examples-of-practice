A client and server demo
