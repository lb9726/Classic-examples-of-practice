
characteristics of cloud:

	01) all event driven framework
	02) socket + signal + timer
	03) single thread
	04) only process connect, close and receive
	05) send data automatically
	06) no block
	07) only for linux platform
	08) simple but robust
	09) client should send socket first
	10) heart beat mechanism shoulde be taken by user

