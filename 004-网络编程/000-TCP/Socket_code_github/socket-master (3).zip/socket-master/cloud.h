
#ifndef _CLOUD_H
#define _CLOUD_H

void cloud_init();
void cloud_run(int sock);

#endif
