
#ifndef _IO_H
#define _IO_H

void io_init();


#endif

