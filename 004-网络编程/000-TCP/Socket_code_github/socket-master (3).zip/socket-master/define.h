
#ifndef _DEFINE_H
#define _DEFINE_H

// hash for receive sock

#define HANDLE_HASH_NUM 10

// hash for send sock

#define HASH_SEND_SOCK_NUM 10

// event number

#define MAX_EVENT_NUM 1024

// read buffer size

#define READ_BUF_SIZE (1024)

#endif
